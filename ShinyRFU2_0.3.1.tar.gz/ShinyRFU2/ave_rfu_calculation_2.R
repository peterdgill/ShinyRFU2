# --- ave_rfu_internal --- FINAL VERSION (Model Loop REMOVED - Only Uses Mod=3 Settings) ---
# Uses "Old Logic" for Hp conditioning setup (condHp=nCOND:1).
# Uses LR = Hp / Hd, where Hd uses "Old Logic" workaround.
# Calculates using ONLY Model 3 settings (BW+FW Stutter, Kit Degradation if specified).
# Builds results row-by-row in a list. Corrected initialization.

#' Perform RFU/LR Calculation (Internal Helper)
#' @description Runs euroformix likelihood calculations for all hypotheses.
#'   Uses "Old Logic" for conditioning setup to avoid potential euroformix errors.
#'   Calculates LR = Hp(POI+Cond+Unk) / Hd(Cond+Unk replacing POI or All Unk).
#'   Uses Model 3 settings (BW+FW stutter, kit degradation).
#' @param popFreq Population frequency list.
#' @param evidData Evidence data frame (full).
#' @param refData Reference data frame (full).
#' @param hypData Hypotheses data frame (full table). # <<< Takes full table
#' @param kit Kit name string or NULL.
#' @param AT Analytical threshold.
#' @param fst Fst value.
#' @param pC Drop-in probability.
#' @param lambda Drop-in lambda parameter.
#' @param seed Random seed.
#' @param steptol Optimization tolerance.
#' @param nDone Number of optimization runs.
#' @param sig Number of significant digits for theta output.
#' @param session Shiny session object (optional, for progress updates).
#' @return A data frame containing the results for all processed hypotheses.
#' @keywords internal
#' @importFrom stats na.omit setNames
#' @importFrom utils head
#' Perform RFU/LR Calculation (Internal Helper)
#' @description Runs euroformix likelihood calculations for all hypotheses.
#' @param ... Arguments passed from the main Shiny app function.
#' @return A data frame containing the results for all processed hypotheses.
#' @keywords internal
#' @noRd
ave_rfu_internal <- function(popFreq, evidData, refData, hypData, # <<< Takes full hypData
                             kit, AT, fst, pC, lambda,
                             seed = 1, steptol = 1e-6, nDone = 3, sig = 5,
                             session = NULL) {

  # Ensure required packages are loaded via NAMESPACE
  # if (!requireNamespace("euroformix", quietly = TRUE)) stop("Package 'euroformix' needed.", call. = FALSE)
  # if (!is.null(session) && !requireNamespace("shinybusy", quietly = TRUE)) {
  #     warning("shinybusy package needed.", call. = FALSE); session <- NULL
  # }
  # if (!requireNamespace("dplyr", quietly = TRUE)) stop("Package 'dplyr' needed.", call. = FALSE)


  # HELPFUNCTION for obtaining MAC
  MAC2 <- function(x, y) return(as.numeric(x[1] %in% y) + as.numeric(x[2] %in% y))

  # Basic Checks (that don't depend on hypData structure yet)
  if (is.null(names(popFreq)) || length(names(popFreq)) == 0) stop("Population frequency data ('popFreq') must be a named list.", call.=FALSE)
  locs <- names(popFreq)

  # --- Moved Definitions Inside Function Body --- <<< MOVED HERE
  # Define calculation column names (these are fixed)
  calc_colnames <- c("loglikhp", "loglikhd", "LRmle", "thetaHp", "thetaHd",
                     "MAC", "nDropout", "nAunknown", "nRefAlleles", "nAlleles", "avgRFU",
                     "Status", "ErrorMessage")

  # Get hypData column names and check them now that hypData exists
  hyp_colnames <- colnames(hypData)
  if (any(hyp_colnames == "" | is.na(hyp_colnames))) stop("Hypotheses file contains empty or NA column names in header.", call. = FALSE)

  # Define full output column order
  all_colnames <- c(hyp_colnames, calc_colnames)

  # Initialize results list (now safe to use nrow)
  all_results_list <- vector("list", nrow(hypData))
  # --- End Moved Definitions ---


  # LOOPING THROUGH EACH HYPOTHESIS SET:
  for (hyprow in 1:nrow(hypData)) {

    # --- Report Progress ---
    progress_value <- hyprow / nrow(hypData)
    progress_text <- paste("Processing Hypothesis set #", hyprow, "of", nrow(hypData))
    print(progress_text) # Keep console print
    if (!is.null(session) && inherits(session, "ShinySession")) {
      # Use :: for clarity
      shinybusy::update_modal_spinner(text = progress_text, session = session)
    }
    # --- End Report Progress ---

    # Initialize results for this row (as a list)
    current_row_results <- as.list(hypData[hyprow, , drop = FALSE]) # Start with input hyp data
    for(col in calc_colnames) { current_row_results[[col]] <- NA } # Add NA placeholders
    current_row_results$Status <- "Failure" # Default status
    current_row_results$ErrorMessage <- "Processing not completed." # Default error

    # --- START: tryCatch for row processing ---
    tryCatch({
      # Extract info directly from the input row list
      evidUse = current_row_results[[hyp_colnames[1]]] # Use name from input row
      POI = current_row_results[["POI"]]
      COND_raw = current_row_results[["Cond"]]
      NOC =  as.integer(current_row_results[["NOC"]])

      # Basic checks
      if (!evidUse %in% unique(evidData[, "Sample Name"])) stop("Evidence sample not found in Evidence file.", call. = FALSE)
      if (is.na(NOC) || NOC <= 0) stop("Invalid NOC.", call. = FALSE)

      # Process COND & POI for refUse creation
      COND = COND_raw; if (!is.na(COND) && COND == "") COND = NA
      POI_val = POI; if (!is.na(POI_val) && POI_val == "") POI_val = NA
      refUse = unique(stats::na.omit(c(POI_val, COND))) # Use stats::

      # Build reference list
      refUseList <- list()
      if (length(refUse) > 0) {
        refData_sample_names <- unique(refData[, "Sample Name"])
        missing_refs <- base::setdiff(refUse, refData_sample_names) # Use base::
        if (length(missing_refs) > 0) stop(paste("Reference(s)", paste(shQuote(missing_refs), collapse=", "), "not found."), call. = FALSE)
        refUseTable = refData[refData$`Sample Name` %in% refUse, , drop = FALSE]
        tempRefList <- euroformix::sample_tableToList(refUseTable)
        refUseList  <- list(); for(ref_name in refUse) { if(ref_name %in% names(tempRefList)) refUseList[[ref_name]] <- tempRefList[[ref_name]] }
      }

      # Prepare data
      evidUseTable = evidData[evidData$`Sample Name` == evidUse, , drop = FALSE]
      evidUseList  = euroformix::sample_tableToList(evidUseTable)
      dat <- euroformix::prepareData(evidUseList, refData = refUseList, popFreq = popFreq, threshT = AT)
      if (is.null(dat$samples) || length(dat$samples) == 0 || length(dat$samples[[1]]) == 0) stop("No valid loci/data after prepareData.", call. = FALSE)

      # Calculate Stats
      nAlleles = sum(sapply(dat$samples[[1]], function(x) length(x$adata)))
      locus_sums <- sapply(dat$samples[[1]], function(x) sum(x$hdata, na.rm = TRUE))
      avgRFU = ifelse(length(locus_sums) > 0, mean(locus_sums, na.rm = TRUE), 0)
      nRefs = length(refUseList)
      MACmat <- NULL; mactxt <- "N/A"; dotxt <- "N/A"
      if (nRefs > 0) { # MAC calculation (condensed)
        refUseNames <- names(refUseList); MACmat <- matrix(0, ncol = 1, nrow = nRefs, dimnames = list(refUseNames, "MAC"))
        if (!is.null(dat$refData) && length(dat$refData)>0) {
          for (rr_idx in 1:nRefs) { rr <- refUseNames[rr_idx]; for (loc in names(dat$samples[[1]])) { if (loc %in% names(dat$refData) && !is.null(dat$refData[[loc]]) && rr %in% names(dat$refData[[loc]])) { ref_alleles <- dat$refData[[loc]][[rr]]; evid_alleles <- dat$samples[[1]][[loc]]$adata; if (is.atomic(ref_alleles) && !is.null(ref_alleles) && is.atomic(evid_alleles) && !is.null(evid_alleles)) { MACmat[rr_idx, 1] <- MACmat[rr_idx, 1] + MAC2(ref_alleles, evid_alleles) }}}}
          totndrops <- length(names(dat$samples[[1]])) * 2 - MACmat[, 1]; names(totndrops) = refUseNames
          mactxt = paste0(paste0(rownames(MACmat), "=", MACmat[,1]), collapse = "/"); dotxt = paste0(paste0(names(totndrops), "=", totndrops), collapse = "/")
        } else { warning(paste("dat$refData NULL/empty for sample", evidUse), call.=FALSE) }
      }
      # Placeholders
      nAu = NA; hAu = NA; nA_refs = rep(NA, nRefs)
      nAutxt = paste0("nU=", nAu, "/hU=", hAu); nArtxt = if (nRefs > 0) paste0(paste0(names(refUseList), "=", nA_refs), collapse = "/") else "N/A"

      # Assign stats results
      current_row_results$MAC <- mactxt; current_row_results$nDropout <- dotxt
      current_row_results$nAunknown <- nAutxt; current_row_results$nRefAlleles <- nArtxt
      current_row_results$nAlleles <- nAlleles; current_row_results$avgRFU <- avgRFU

      # Initialize results for calculation block
      loghp <- NA; loghd <- NA; LRmle <- NA; thhatp <- "N/A"; thhatd <- "N/A"
      calculation_status_message <- NA # Reset specific error message

      # --- Set Model Parameters (Equivalent to old mod=3) ---
      kit0 <- NULL; xiBW <- NULL; xiFW <- NULL
      if (!is.null(kit) && kit != "") {
        kit_params <- euroformix::getKit(kit)
        if (!is.null(kit_params)) { kit0 <- kit }
        else { warning(paste("Kit", shQuote(kit), "not found for sample", evidUse, "."), call. = FALSE) }
      }
      # --- End Model Parameter Setup ---

      # --- Setup conditioning using OLD logic ---
      nCOND_old = length(refUse)
      condHp <- NULL; condHd_old <- NULL; knownRef_old <- NULL
      if(nCOND_old > 0) { condHp <- condHd_old <- nCOND_old:1 }
      if (!is.na(POI) && POI != "") {
        if (nCOND_old == 0 ) stop("POI specified but no refs available.")
        if(is.null(condHd_old)) condHd_old <- nCOND_old:1
        condHd_old[1] = 0; knownRef_old = 1
      } else { knownRef_old = NULL }
      # --- End OLD logic setup ---

      # --- Perform Calculations ---
      if (!is.na(POI) && POI != "") { # POI is present

        # --- Hp Calculation ---
hpfit <- NULL
current_condHp <- if (is.null(condHp) && nCOND_old > 0) nCOND_old:1 else condHp

tryCatch({

  hpfit <- euroformix::contLikMLE(
    nC         = NOC,
    samples    = dat$samples,
    refData    = dat$refData,
    popFreq    = dat$popFreq,
    threshT    = AT,
    verbose    = FALSE,
    xi         = xiBW,
    xiFW       = xiFW,
    kit        = kit0,
    condOrder  = current_condHp,
    prC        = pC,
    lambda     = lambda,
    fst        = fst,
    nDone      = nDone,
    steptol    = steptol,
    seed       = seed
  )

  if (!is.null(hpfit) &&
      !is.null(hpfit$fit$loglik) &&
      is.finite(hpfit$fit$loglik)) {
    loghp   <- hpfit$fit$loglik
    thhatp  <- paste0(signif(hpfit$fit$thetahat2, sig), collapse = "/")
  } else {
    calculation_status_message <- "Hp calc non-finite/NULL"
  }

}, error = function(e_hp) {

  # Check for the exact “replacement has length zero” condition
  if (grepl("replacement has length zero", e_hp$message, ignore.case = TRUE)) {
    warning(
      sprintf(
        "Warning: Hp Sample %s : replacement has length zero.\n  Caused by loci present in reference file that are not in the evidence file.\n  Delete columns containing loci that are not needed from the population frequency file",
        evidUse
      ),
      call. = FALSE
    )
  } else {
    # Fallback to the original error message
    warning(
      sprintf("Error Hp Sample %s : %s", evidUse, e_hp$message),
      call. = FALSE
    )
  }

  # Store a compact status message for downstream use
  calculation_status_message <<- paste("Hp Error:", e_hp$message)
})
###################################
        ##DEBUG STATEMENTS
        # === DEBUG (before Hd) ===
        if (!is.na(COND_raw)) {
          # We are in “Hd = Cond + (NOC−1) unknowns” mode
          num_known_hd <- 1
          num_unknowns_hd <- NOC - 1
          message(
            sprintf(
              "DEBUG [Hd]: Cond='%s', NOC=%d  ⇒  forced‐known=%d, fitted‐unknown=%d",
              COND_raw, NOC, num_known_hd, num_unknowns_hd
            )
          )
        } else {
          # We are in “Hd = All Unknowns” mode
          num_known_hd <- 0
          num_unknowns_hd <- NOC
          message(
            sprintf(
              "DEBUG [Hd]: Cond='<none>', NOC=%d  ⇒  forced‐known=%d, fitted‐unknown=%d",
              NOC, num_known_hd, num_unknowns_hd
            )
          )
        }
        # ========================
        #######END DEBUG STATEMENTS###########################
        # --- Hd Calculation ---
        hdfit <- NULL
        if (!is.na(loghp)) { # Only proceed if Hp was successful
          if (!is.na(COND)) { # Hd = Cond + Unknown(s) replacing POI (OLD logic)
            tryCatch({
              if(is.null(condHd_old) || is.null(knownRef_old)) stop("Hd(Cond+Unk) params not set.")
              hdfit <- euroformix::contLikMLE(nC = NOC, samples = dat$samples, refData = dat$refData, popFreq = dat$popFreq, threshT = AT, verbose = FALSE, xi = xiBW, xiFW = xiFW, kit = kit0, condOrder = condHd_old, knownRef = knownRef_old, prC = pC, lambda = lambda, fst = fst, nDone = nDone, steptol = steptol, seed = seed)
              if (!is.null(hdfit) && !is.null(hdfit$fit$loglik) && is.finite(hdfit$fit$loglik)) { loghd <- hdfit$fit$loglik; thhatd <- paste0(signif(hdfit$fit$thetahat2, sig), collapse = "/") }
              else { calculation_status_message <- paste(calculation_status_message, "Hd(Cond+Unk) calc non-finite/NULL", collapse="; ") }
            }, error = function(e_hd) { warning(paste("Error Hd(Cond+Unk) Sample", evidUse, ":", e_hd$message), call. = FALSE); calculation_status_message <<- paste(calculation_status_message, paste("Hd(Cond+Unk) Error:", e_hd$message), collapse="; ") }) # Use <<-
          } else { # Hd = All Unknowns
            tryCatch({
              hdfit <- euroformix::contLikMLE(nC = NOC, samples = dat$samples, refData = dat$refData, popFreq = dat$popFreq, threshT = AT, verbose = FALSE, xi = xiBW, xiFW = xiFW, kit = kit0, condOrder = NULL, knownRef = 1, prC = pC, lambda = lambda, fst = fst, nDone = nDone, steptol = steptol, seed = seed)
              if (!is.null(hdfit) && !is.null(hdfit$fit$loglik) && is.finite(hdfit$fit$loglik)) { loghd <- hdfit$fit$loglik; thhatd <- paste0(signif(hdfit$fit$thetahat2, sig), collapse = "/") }
              else { calculation_status_message <- paste(calculation_status_message, "Hd(AllUnk) calc non-finite/NULL", collapse="; ") }
            }, error = function(e_hd) { warning(paste("Error Hd(AllUnk) Sample", evidUse, ":", e_hd$message), call. = FALSE); calculation_status_message <<- paste(calculation_status_message, paste("Hd(AllUnk) Error:", e_hd$message), collapse="; ") }) # Use <<-
          }
        } else { loghd <- NA; thhatd <- "N/A"; if (is.na(calculation_status_message)) calculation_status_message <- "Hp failed." }

      } else { # POI is NA or ""
        # Only Hp (Likelihood) is calculated
        hpfit <- NULL; loghd <- NA; thhatd <- "N/A"; LRmle <- NA
        current_condHp <- if(is.null(condHp) && nCOND_old > 0) { nCOND_old:1 } else { condHp }
        tryCatch({
          hpfit <- euroformix::contLikMLE(nC = NOC, samples = dat$samples, refData = dat$refData, popFreq = dat$popFreq, threshT = AT, verbose = FALSE, xi = xiBW, xiFW = xiFW, kit = kit0, condOrder = current_condHp, prC = pC, lambda = lambda, fst = fst, nDone = nDone, steptol = steptol, seed = seed)
          if (!is.null(hpfit) && !is.null(hpfit$fit$loglik) && is.finite(hpfit$fit$loglik)) { loghp <- hpfit$fit$loglik; thhatp <- paste0(signif(hpfit$fit$thetahat2, sig), collapse = "/") }
          else { calculation_status_message <- "Likelihood(no POI) calc non-finite/NULL" }
        }, error = function(e_hp) { warning(paste("Error Likelihood(no POI) Sample", evidUse, ":", e_hp$message), call. = FALSE); calculation_status_message <<- paste("Likelihood(no POI) Error:", e_hp$message) }) # Use <<-
      } # End if/else for POI presence

      # --- Calculate LR and set Status ---
      final_status <- "Failure"
      if (!is.na(loghp) && !is.na(loghd) && is.finite(loghp) && is.finite(loghd)) { LRmle <- exp(loghp - loghd); final_status <- "Success"; calculation_status_message <- NA }
      else if (!is.na(loghp) && is.finite(loghp) && (is.na(POI) || POI == "")) { LRmle <- NA; final_status <- "Success (Likelihood only)"; calculation_status_message <- NA }
      else { LRmle <- NA; final_status <- "Failure"; if (is.na(calculation_status_message)) calculation_status_message <- "Calculation failed (loglik invalid)." }

      # Assign final results for the row
      current_row_results$loglikhp <- loghp
      current_row_results$loglikhd <- loghd
      current_row_results$LRmle <- LRmle
      current_row_results$thetaHp <- thhatp
      current_row_results$thetaHd <- thhatd
      current_row_results$Status <- final_status
      current_row_results$ErrorMessage <- calculation_status_message

    }, error = function(e) { # Catch STOP errors during data prep/loop setup
      print(paste("STOP Error processing row for sample", evidUse, ":", e$message))
      current_row_results$Status <- "Error"
      current_row_results$ErrorMessage <- e$message
      # Other values remain NA
    }) # End tryCatch for the hypothesis row processing

    # Store the final results list for this row
    all_results_list[[hyprow]] <- current_row_results

  } # end for each hypothesis row

  # Combine list of results into a final data frame
  # Use dplyr::bind_rows explicitly
  #final_results_df <- dplyr::bind_rows(all_results_list)
# new: use base-R pipe
final_results_df <- all_results_list |> dplyr::bind_rows()

  # Ensure column order matches initial intention if needed
  # Define all_colnames again here just in case loop didn't run
  hyp_colnames <- colnames(hypData) # Use original hypData colnames
  calc_colnames <- c("loglikhp", "loglikhd", "LRmle", "thetaHp", "thetaHd",
                     "MAC", "nDropout", "nAunknown", "nRefAlleles", "nAlleles", "avgRFU",
                     "Status", "ErrorMessage")
  all_colnames <- c(hyp_colnames, calc_colnames)
  # Add any missing columns and reorder
  for(col in setdiff(all_colnames, colnames(final_results_df))) { final_results_df[[col]] <- NA }
  final_results_df <- final_results_df[, all_colnames]

  # Return as data frame
  return(as.data.frame(final_results_df, stringsAsFactors = FALSE))
} # End ave_rfu_internal function


