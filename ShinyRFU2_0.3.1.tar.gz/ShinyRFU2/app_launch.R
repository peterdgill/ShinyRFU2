# --- Helper Function: Validation ---
#' Validate Inputs (Internal Helper)
#' @description Checks input data frames and parameters.
#' @param evidData Evidence data frame.
#' @param refData Reference data frame.
#' @param hypData Hypotheses data frame.
#' @param popFreq Population frequency list.
#' @param AT Analytical threshold.
#' @param fst Fst value.
#' @param pC Drop-in probability.
#' @param lambda Drop-in lambda parameter.
#' @param kit Kit name string or NULL.
#' @return List of error messages (character vector) or NULL if validation passes.
#' @keywords internal
#' @importFrom stats na.omit
#' @importFrom utils head
validate_inputs <- function(evidData, refData, hypData, popFreq, AT, fst, pC, lambda, kit) {
  # --- Function content as provided previously ---
  # (Includes checks for dataframes, columns, types, consistency, markers, params, kit)
  # ... (Assume this function is correct based on previous versions) ...
  errors <- list()
  # ... (All validation checks) ...
  if (length(errors) == 0) {
    return(NULL)
  } else {
    return(unlist(errors))
  }
}


# --- Helper Function: Summary Sheet ---
#' Create Summary Sheet (Internal Helper)
#' @description Processes main results into summary format.
#' @param main_results_df Data frame from ave_rfu_internal.
#' @return Summary data frame.
#' @keywords internal
#' @importFrom dplyr bind_rows
#' @importFrom stats setNames na.omit
#' @importFrom utils head
create_summary_sheet <- function(main_results_df) {
  # Check if input is valid
  if (is.null(main_results_df) || !inherits(main_results_df, "data.frame") || nrow(main_results_df) == 0) {
    warning("Input to create_summary_sheet is not a valid data frame.", call. = FALSE)
    return(data.frame()) # Return empty
  }

  summary_list <- list()
  # Define column names
  summary_colnames <- c("Sample Name", "POI", "Cond", "NOC", "LRmle",
                        "MxPOI", "MxCond", "MxU1", "MxU2", "MxU3",
                        "Status", "ErrorMessage", "SummaryValidation")
  # Define column types for initialization (helps bind_rows)
  col_types <- list(
    "Sample Name" = NA_character_, "POI" = NA_character_, "Cond" = NA_character_,
    "NOC" = NA_integer_, "LRmle" = NA_real_,
    "MxPOI" = NA_real_, "MxCond" = NA_real_, "MxU1" = NA_real_, "MxU2" = NA_real_, "MxU3" = NA_real_,
    "Status" = NA_character_, "ErrorMessage" = NA_character_, "SummaryValidation" = NA_character_
  )


  main_colnames <- colnames(main_results_df)
  evidence_col_name <- "Sample Name"
  if (!evidence_col_name %in% main_colnames) {
    warning("Column 'Sample Name' missing in results, using first column as fallback.", call.=FALSE)
    evidence_col_name <- main_colnames[1]
    if (!evidence_col_name %in% main_colnames) {
      warning("Could not determine Sample Name column.", call.=FALSE)
      return(data.frame())
    }
  }

  print(paste("--- Debug: Starting Summary Sheet Creation. Expecting Sample Name col:", evidence_col_name, "---")) # DEBUG

  for (i in 1:nrow(main_results_df)) {
    row_main <- main_results_df[i, ]
    # Initialize summary row using defined types
    row_summary <- col_types # Start with correctly typed NAs

    # --- Copy basic info ---
    # Ensure source column exists before copying
    if (evidence_col_name %in% main_colnames) row_summary[["Sample Name"]] <- as.character(row_main[[evidence_col_name]]) # Ensure character
    if ("POI" %in% main_colnames) row_summary[["POI"]] <- as.character(row_main[["POI"]])
    if ("Cond" %in% main_colnames) row_summary[["Cond"]] <- as.character(row_main[["Cond"]])
    if ("NOC" %in% main_colnames) row_summary[["NOC"]] <- suppressWarnings(as.integer(row_main[["NOC"]]))
    if ("LRmle" %in% main_colnames) row_summary[["LRmle"]] <- suppressWarnings(as.numeric(row_main[["LRmle"]]))
    if ("Status" %in% main_colnames) row_summary[["Status"]] <- as.character(row_main[["Status"]])
    if ("ErrorMessage" %in% main_colnames) row_summary[["ErrorMessage"]] <- as.character(row_main[["ErrorMessage"]])

    # --- DEBUG PRINT START ---
    print(paste("Debug Row", i, "- Copied Sample Name:", row_summary[["Sample Name"]]))
    # --- DEBUG PRINT END ---

    # --- Process thetaHp ---
    summary_validation_status <- "OK"; error_messages <- c()
    original_status <- row_summary[["Status"]]; thetaHp_str <- NA
    if ("thetaHp" %in% main_colnames) thetaHp_str <- row_main[["thetaHp"]]
    noc <- row_summary[["NOC"]]

    if (!is.na(original_status) && grepl("Success", original_status) && !is.na(thetaHp_str) && nzchar(thetaHp_str) && !is.na(noc) && noc > 0) {
      mx_values_str <- strsplit(as.character(thetaHp_str), "/")[[1]] # Ensure character
      num_available = length(mx_values_str); num_to_take = min(noc, num_available)
      mx_values_calc <- suppressWarnings(as.numeric(utils::head(mx_values_str, num_to_take)))

      if (length(mx_values_calc) != noc || any(is.na(mx_values_calc))) {
        error_messages <- c(error_messages, paste0("Fail parse Mx from thetaHp")); summary_validation_status <- "Fail: Mx Parsing"
      } else {
        mx_sum <- sum(mx_values_calc)
        if (abs(mx_sum - 1) > 1e-2) { error_messages <- c(error_messages, paste0("Mx sum ", round(mx_sum, 6), "!=~1")); summary_validation_status <- "Fail: Mx Sum" }
        cond_val <- row_summary[["Cond"]]; cond_is_na_or_empty <- is.na(cond_val) || cond_val == ""
        if (!cond_is_na_or_empty) { if (noc > 5 || noc < 2) { error_messages <- c(error_messages, "Invalid NOC (Cond)"); summary_validation_status <- "Fail: NOC Limit" }
        } else { if (noc > 4) { error_messages <- c(error_messages, "Invalid NOC (No Cond)"); summary_validation_status <- "Fail: NOC Limit" } }
        if (!grepl("NOC Limit", summary_validation_status)) {
          if (cond_is_na_or_empty) {
            if (noc >= 1) row_summary[["MxPOI"]] <- signif(mx_values_calc[1], 3)
            if (noc >= 2) row_summary[["MxU1"]]  <- signif(mx_values_calc[2], 3)
            if (noc >= 3) row_summary[["MxU2"]]  <- signif(mx_values_calc[3], 3)
            if (noc >= 4) row_summary[["MxU3"]]  <- signif(mx_values_calc[4], 3)
            row_summary[["MxCond"]] <- NA_real_ # Use typed NA
          } else {
            if (noc >= 1) row_summary[["MxCond"]] <- signif(mx_values_calc[1], 3)
            if (noc >= 2) row_summary[["MxPOI"]]  <- signif(mx_values_calc[2], 3)
            if (noc >= 3) row_summary[["MxU1"]]  <- signif(mx_values_calc[3], 3)
            if (noc >= 4) row_summary[["MxU2"]]  <- signif(mx_values_calc[4], 3)
            if (noc >= 5) row_summary[["MxU3"]]  <- signif(mx_values_calc[5], 3)
          }
        }
      }
    }
    # --- End Process thetaHp ---

    # Update Error Message and Validation Status
    row_summary[["SummaryValidation"]] <- summary_validation_status
    if (length(error_messages) > 0) {
      original_error <- row_summary[["ErrorMessage"]]; new_error_string <- paste(error_messages, collapse = "; ")
      combined_error <- if (is.na(original_error) || !nzchar(original_error)) { paste("Summary Validation:", new_error_string) } else { trimws(paste(original_error, paste("Summary Validation:", new_error_string), sep = "; ")) }
      row_summary[["ErrorMessage"]] <- combined_error
    } else {
      # Ensure ErrorMessage is NA if no errors (original or new)
      if(is.na(row_summary[["ErrorMessage"]])) row_summary[["ErrorMessage"]] <- NA_character_
    }
    summary_list[[i]] <- row_summary # Store the list directly

  } # End loop

  # Combine list into data frame
  if(length(summary_list) > 0) {
    final_summary_df <- dplyr::bind_rows(summary_list) # Use dplyr::
    # Ensure column order matches initial intention
    final_summary_df <- final_summary_df[, summary_colnames]
    # Types should be mostly correct due to initialization and bind_rows,
    # but can re-check numerics if needed
    # numeric_cols <- c("NOC", "LRmle", "MxPOI", "MxCond", "MxU1", "MxU2", "MxU3")
    # for(col in intersect(numeric_cols, colnames(final_summary_df))){ final_summary_df[[col]] <- suppressWarnings(as.numeric(as.character(final_summary_df[[col]]))) }
  } else { final_summary_df <- data.frame(matrix(ncol = length(summary_colnames), nrow = 0, dimnames=list(NULL, summary_colnames)), stringsAsFactors = FALSE) }

  # --- DEBUG PRINT START ---
  print("--- Debug: Final structure of summary_df before return: ---")
  print(utils::str(final_summary_df))
  print("--- Debug: End Summary Sheet Creation ---")
  # --- DEBUG PRINT END ---

  return(final_summary_df)
}


#' Launch the Shiny Average RFU Application
#'
#' @description
#' Launches a Shiny web application for calculating likelihood ratios
#' and related statistics for forensic DNA mixtures using the euroformix package.
#' Allows upload of evidence, reference, hypothesis, and frequency files,
#' setting of parameters, and download of results in a multi-sheet Excel report.
#'
#' @details
#' The application performs calculations based on the provided inputs and an
#' internal calculation function (`ave_rfu_internal`). It includes input validation and
#' generates both a main results table and a summary table. The underlying
#' calculation uses the most complex stutter model (BW+FW) and kit degradation.
#' The LR compares Hp (POI + Cond + Unk) vs Hd (Cond + Unk replacing POI or All Unk if Cond absent).
#'
#' @return This function normally does not return a value; it launches a Shiny application.
#'   If required packages (shiny, euroformix, etc.) are not installed, it may stop with an error.
#'
#' @export
#' @importFrom magrittr %>%
#'
#' @examples
#' \dontrun{
#' # Ensure the ShinyRFU2 package is loaded:
#' # library(ShinyRFU2)
#'
#' # Launch the application:
#' ShinyRFU2()
#' }
ShinyRFU2 <- function() {

  # Check if shiny is available (namespace is loaded when package loads)
  if (!requireNamespace("shiny", quietly = TRUE)) {
    stop("Package 'shiny' is required to run this application. Please install it.", call. = FALSE)
  }
  # Check other critical dependencies needed immediately for UI/Server setup
  if (!requireNamespace("DT", quietly = TRUE)) stop("Package 'DT' required.", call. = FALSE)
  if (!requireNamespace("shinybusy", quietly = TRUE)) stop("Package 'shinybusy' required.", call. = FALSE)


  # Define UI inside the function
  ui <- shiny::fluidPage(

    ## App title ---
    shiny::titlePanel("Average RFU and LR Calculation using euroformix"),

    shiny::sidebarLayout(
      shiny::sidebarPanel(
        width = 4,
        shiny::h3("1. Set Parameters"),
        shiny::numericInput("ATvalue", label = ("Analytical Threshold (AT):"), value = 50, min = 1),
        shiny::numericInput("Fstvalue", label = ("Fst (Theta correction):"), value = 0.01, min = 0, max = 1, step = 0.01),
        shiny::numericInput("PCvalue", label = ("Drop-in probability (pC):"), value = 0.05, min = 0, max = 1, step = 0.01),
        shiny::numericInput("lambdavalue", label = ("Lambda (Drop-in parameter):"), value = 0.01, min = 0.001, step = 0.01),
        shiny::selectInput("kit", "Select kit (influences stutter/degradation):",
                           # Use tryCatch for getKit
                           choices = c("Select Kit" = "", tryCatch(euroformix::getKit(), error=function(e) {warning("Could not get kit list.", call.=FALSE); NULL})),
                           selected = "GlobalFiler"),

        shiny::hr(),
        shiny::h3("2. Upload Data Files (.csv or .txt)"),
        shiny::fileInput("evidence", "Evidence File", multiple = FALSE, accept = c("text/csv", "text/comma-separated-values,text/plain", ".csv", ".txt")),
        shiny::fileInput("reference", "Reference File", multiple = FALSE, accept = c("text/csv", "text/comma-separated-values,text/plain", ".csv", ".txt")),
        shiny::fileInput("hypotheses", "Hypotheses File", multiple = FALSE, accept = c("text/csv", "text/comma-separated-values,text/plain", ".csv", ".txt")),
        shiny::fileInput("popfreq", "Population Frequencies", multiple = FALSE, accept = c("text/csv", "text/comma-separated-values,text/plain", ".csv", ".txt")),

        shiny::hr(),
        shiny::h3("3. Run Calculation"),
        shiny::actionButton("goButton", "Press to Validate and Calculate", icon = shiny::icon("cogs"),
                            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"),
        shiny::hr(),
        shiny::h3("4. Download Results"),
        shiny::uiOutput("downloadBtnUI")
      ),
      shiny::mainPanel(
        width = 8,
        shiny::h3("Results Overview (Main)"),
        DT::dataTableOutput("resultsTable")
      )
    )
  ) # End fluidPage

  # Define server logic inside the function
  server <- function(input, output, session) {

    results_data <- shiny::reactiveVal(NULL)
    summary_data <- shiny::reactiveVal(NULL)

    output$downloadBtnUI <- shiny::renderUI({
      if (!is.null(results_data()) && inherits(results_data(), "data.frame")) {
        shiny::downloadButton("downloadData", "Download Excel Report (.xlsx)", class = "btn-success")
      } else {
        shiny::actionButton("downloadData_disabled", "Download Report (Requires Calculation)", disabled = TRUE)
      }
    })

    shiny::observeEvent(input$goButton, {
      results_data(NULL); summary_data(NULL) # Reset

      # Use shinybusy:: modal spinner
      shinybusy::show_modal_spinner(spin = "cube-grid", color = "#1D6FB3", text = "Starting analysis...")
      on.exit(shinybusy::remove_modal_spinner(), add = TRUE) # Ensure removal

      resTable <- NULL; calculation_success <- FALSE

      tryCatch({
        # 1. Check required files
        shiny::req(input$evidence$datapath, input$hypotheses$datapath, input$popfreq$datapath, cancelOutput = TRUE)

        shinybusy::update_modal_spinner("Reading input files...")

        # 2. Read files (use :: explicitly)
        evidData <- euroformix::tableReader(input$evidence$datapath)
        hypData <- euroformix::tableReader(input$hypotheses$datapath)
        popFreqList <- euroformix::freqImport(input$popfreq$datapath)
        popFreq <- if (length(popFreqList) > 0) popFreqList[[1]] else stop("freqImport failed.")

        refData <- NULL
        if (!is.null(input$reference$datapath)) {
          refData <- euroformix::tableReader(input$reference$datapath)
        } else {
          shiny::showNotification("No reference file uploaded.", type="warning", duration=8)
          # Create empty placeholder for validation function if NULL
          req_ref_cols <- c("Sample Name", "Marker", "Allele 1")
          refData <- data.frame(matrix(ncol = length(req_ref_cols), nrow = 0, dimnames=list(NULL, req_ref_cols)), stringsAsFactors = FALSE)
        }
        if(is.null(evidData) || is.null(hypData) || is.null(popFreq)) stop("Essential input files failed to load.")

        shinybusy::update_modal_spinner("Validating data content...")

        # 3. Validate data content
        selected_kit_val <- input$kit; if(selected_kit_val == "") selected_kit_val <- NULL
        # Call internal helper function (defined above)
        validation_errors <- validate_inputs(evidData=evidData, refData=refData, hypData=hypData, popFreq=popFreq, AT=input$ATvalue, fst=input$Fstvalue, pC=input$PCvalue, lambda=input$lambdavalue, kit=selected_kit_val)

        if (!is.null(validation_errors)) {
          err_html <- paste("Input validation failed:", paste(paste("<li>", validation_errors, "</li>"), collapse = ""))
          shiny::showNotification(shiny::HTML(err_html), type = "error", duration = NULL)
          stop("Input validation failed.")
        }

        shinybusy::update_modal_spinner("Validation successful. Starting calculation...")

        # 4. Run the calculation function
        selected_kit_calc <- input$kit; if(selected_kit_calc == "") selected_kit_calc <- NULL

        # Call internal function ave_rfu_internal (defined in another file in R/)
        # This function needs to be available in the package's namespace
        # Ensure the function name here matches the definition in the other file
        resTable <- ave_rfu_internal(popFreq=popFreq, evidData=evidData, refData=refData, hypData=hypData, kit=selected_kit_calc, AT=input$ATvalue, fst=input$Fstvalue, pC=input$PCvalue, lambda=input$lambdavalue, seed=1, steptol=1e-6, nDone=3, sig=5, session=session)

        if (!is.null(resTable) && inherits(resTable, "data.frame") && nrow(resTable) > 0) { results_data(resTable); calculation_success <- TRUE }
        else { warning("Calculation returned no results."); results_data(NULL) }

      }, error = function(e) { # Catch errors from any step above
        error_msg <- paste("Analysis Error:", e$message)
        shiny::showNotification(error_msg, type = "error", duration = NULL)
        # Store partial results if AveRFU3 created them before erroring
        # Check if resTable was assigned before error
        if (!is.null(resTable) && inherits(resTable, "data.frame")){ results_data(resTable) }
        else { results_data(NULL) }
        calculation_success <- FALSE
      }) # End main tryCatch

      # --- Create Summary Data ---
      if (!is.null(results_data())) {
        shinybusy::update_modal_spinner("Generating summary sheet...")
        tryCatch({
          # Call internal helper function (defined above)
          summary_df <- create_summary_sheet(results_data())
          summary_data(summary_df)
          # Final Notification
          num_success <- sum(results_data()$Status == "Success" | results_data()$Status == "Success (Likelihood only)", na.rm = TRUE)
          num_fail <- sum(results_data()$Status == "Failure" | results_data()$Status == "Error", na.rm = TRUE)
          num_summary_warn <- 0; if(!is.null(summary_data())) { num_summary_warn <- sum(!is.na(summary_data()$SummaryValidation) & summary_data()$SummaryValidation != "OK", na.rm=TRUE) }
          final_message <- paste("Calculation finished.", num_success, "processed,", num_fail, "failed/errors.")
          if(num_summary_warn > 0) { final_message <- paste(final_message, num_summary_warn, "rows had summary validation issues.") }
          shiny::showNotification(final_message, type = "message", duration = 10)
        }, error = function(e_sum) { shiny::showNotification(paste("Error generating summary:", e_sum$message), type = "error"); summary_data(NULL) })
      } else { summary_data(NULL) }
      # --- End Summary ---

    }) # End observeEvent

    output$resultsTable <- DT::renderDataTable({
      shiny::validate(shiny::need(!is.null(results_data()) && nrow(results_data()) > 0, "Results appear here."))
      main_df_display <- results_data()
      # Use magrittr pipe explicitly
      main_df_display %>%
        DT::datatable(
          options = list(scrollX = TRUE, pageLength = 10, scrollCollapse = TRUE, stateSave = TRUE),
          rownames = FALSE, filter = 'top', caption = "Main Calculation Results") %>%
        DT::formatSignif(intersect(c('LRmle'), colnames(main_df_display)), digits = 3) %>%
        DT::formatSignif(intersect(c('loglikhp', 'loglikhd', 'avgRFU'), colnames(main_df_display)), digits = 4)
    })

    output$downloadData <- shiny::downloadHandler(
      filename = function() {
        first_sample <- "Report"; main_df_dl <- results_data()
        if(!is.null(main_df_dl) && nrow(main_df_dl) > 0 && ncol(main_df_dl) > 0) { first_sample_val <- main_df_dl[1, 1]; if(!is.na(first_sample_val) && nzchar(first_sample_val)) { first_sample <- gsub("[^A-Za-z0-9_.-]", "_", first_sample_val) }}
        paste0("AveRFU_Report_", first_sample, "_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".xlsx")
      },
      content = function(file) {
        main_df_dl <- results_data(); summary_df_dl <- summary_data()
        if (!is.null(main_df_dl) && inherits(main_df_dl, "data.frame") && nrow(main_df_dl) > 0 && !is.null(summary_df_dl) && inherits(summary_df_dl, "data.frame")) {
          sheets_list <- list("Main" = main_df_dl, "Summary" = summary_df_dl)
          tryCatch({ openxlsx::write.xlsx(sheets_list, file = file, overwrite = TRUE) },
                   error = function(e){ shiny::showNotification(paste("Error writing Excel:", e$message), type="error"); writeLines(c("Error:", e$message), file) })
        } else {
          error_msg <- "No valid results available."; if(is.null(main_df_dl) || nrow(main_df_dl) == 0) error_msg <- "Main results missing." else if (is.null(summary_data)) error_msg <- "Summary results missing." # Corrected variable name
          writeLines(error_msg, file); shiny::showNotification(error_msg, type="warning")
        }
      }
    ) # End downloadHandler

  } # End server function

  # Launch the app
  shiny::shinyApp(ui = ui, server = server)

} # End ShinyRFU2 function definition

